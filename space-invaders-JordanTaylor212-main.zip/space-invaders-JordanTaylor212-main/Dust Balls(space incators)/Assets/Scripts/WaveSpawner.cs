using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveSpawner : MonoBehaviour

{
    public static WaveSpawner instance;

    [SerializeField] private GameObject[] waves;
    [SerializeField] private float waveSpeed;

    private int waveIndex;
    private GameObject wave;

    



    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }else if (instance != this)
        {
            Destroy(this);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        waveIndex = 0;
        wave = Instantiate(waves[waveIndex]);
        
    }

    // Update is called once per frame
    void Update()
    {
        if (wave != null && wave.transform.childCount == 0) 
        {
            Destroy(wave);
            waveIndex++;
            if (waveIndex < waves.Length)        
            {
                wave = Instantiate(waves[waveIndex]);
                
            } else
            {
                GameManager.instance.YouWin();
            }
        }

       
        
    }
}
