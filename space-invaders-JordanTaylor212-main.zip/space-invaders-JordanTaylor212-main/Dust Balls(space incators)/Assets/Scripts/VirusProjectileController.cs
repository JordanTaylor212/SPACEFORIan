using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VirusProjectileController : MonoBehaviour
{
    [SerializeField] float speed;
    [SerializeField] float range;

    private GameObject player;
    private Vector3 startPosition;


    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        transform.LookAt(player.transform.position);
    }
    // Update is called once per frame
    void Update()
    {
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
        if (Vector3.Distance(startPosition, transform.position) > range)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter(Collider collider)
    {
       
        if (collider.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }

}
