using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private TextMeshProUGUI livesText;
    [SerializeField] private TextMeshProUGUI gameOverText;
    [SerializeField] private int pointsForExtraLife;
    [SerializeField] private AudioClip exraLifeSound;
    [SerializeField] private AudioClip victory;
    [SerializeField] private GameObject endingCredits;
    [SerializeField] private GameObject music;

    private int score;
    private int lives;
    private bool gameOver;
    private int lastExtraLifeScore;
    private AudioSource audioSource;


    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else if (instance != this)
        {
            Destroy(this);
        }
       
    }


    public void addScore(int points)
    {
        score += points;
        int scoreDelta = score - lastExtraLifeScore;
        if (scoreDelta >= pointsForExtraLife)
        {
            lives++;
            lastExtraLifeScore += pointsForExtraLife;
            audioSource.PlayOneShot(exraLifeSound);
        }
    }

    public void LoseLife()
    {
        lives--;
        if (lives == 0)
        {
            gameOver = true;
            gameOverText.enabled = true;
        }
    }
    
    public bool IsGameOver()
    {
        return gameOver;
        if (gameObject.CompareTag("Mosic"))
        {
          Destroy(gameObject);
        }


    }

    public int getScore()
    {
        return score;
    }

    public void YouWin()
    {

        gameOver = true;
        endingCredits.SetActive(true);
        audioSource.PlayOneShot(victory);
    }

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        lives = 3;
        gameOver = false;
        gameOverText.enabled = false;
        endingCredits.SetActive(false);
        lastExtraLifeScore = 0;
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = "Score: " + score;
        livesText.text = "Lives: " + lives;
        if (Input.GetButtonDown("Start") && gameOver)
        {
            Restart(); 
        }

    }

    private void Restart()
    {
        SceneManager.LoadScene(0);
    }
}
