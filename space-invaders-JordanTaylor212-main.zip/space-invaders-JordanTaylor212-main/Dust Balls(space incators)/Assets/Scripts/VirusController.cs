using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VirusController : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float leftEdge;
    [SerializeField] private float rightEdge;
    [SerializeField] private float topEdge;
    [SerializeField] private float bottomEdge;
    [SerializeField] private float rowDelta;
    [SerializeField] private GameObject projectile;
    [SerializeField] private float minFireDelay;


     private bool horizontalMove;
    [SerializeField] private int hDirection;
     private int vDirection;
     private float rowStartZ;
    private float fireDelay;
    private float lastFireTime;


    // Start is called before the first frame update
    void Start()
    {
        horizontalMove = true;
        vDirection = -1;
        fireDelay = Random.Range(minFireDelay, 2 * minFireDelay);
        lastFireTime = Time.time; 
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time - lastFireTime > fireDelay)
        {
            Instantiate(projectile, transform.position, Quaternion.identity);
            lastFireTime = Time.time;
            fireDelay = Random.Range(minFireDelay, 2 * minFireDelay); 
        }

        if (horizontalMove)
        {
            transform.Translate(Vector3.right * hDirection * speed * Time.deltaTime);
            if (transform.position.x < leftEdge && hDirection == -1)
            {
                horizontalMove = false;
                hDirection = 1;
                rowStartZ = transform.position.z;
            }
            if (transform.position.x > rightEdge && hDirection == 1)
            {
                horizontalMove = false;
                hDirection = -1;
                rowStartZ = transform.position.z;
            }
        } 
        else
        {
            transform.Translate(Vector3.forward * vDirection * speed * Time.deltaTime);
            float zDist = Mathf.Abs(rowStartZ - transform.position.z);
            if(zDist > rowDelta)
            {
                horizontalMove = true;
            }
            if (transform.position.z > bottomEdge)
            {
                vDirection = 1;
            }
            if(transform.position.z < topEdge)
            {
                vDirection = -1;
            }
        }
    }
}
