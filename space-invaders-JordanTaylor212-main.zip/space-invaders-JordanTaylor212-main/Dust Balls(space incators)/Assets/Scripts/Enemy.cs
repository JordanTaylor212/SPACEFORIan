using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float attackSpeed;
    [SerializeField] private float xRange;
    [SerializeField] private float xDirection;
    [SerializeField] private float minAttackDelay;
    [SerializeField] private float maxAttackDelay;

    private float attackDelay;
    private float lastAttackTime;
    private bool attacking = false;
    private bool returning = false;
    private Vector3 targetPosition;
    private Vector3 returnPosition;
    private GameObject player;




    // Start is called before the first frame update
    void Start()
    {
        lastAttackTime = Time.time;
        attackDelay = Random.Range(minAttackDelay, maxAttackDelay);
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        if (!attacking)
        {
            float attackDelta = Time.time - lastAttackTime;
            if (attackDelta > attackDelay)
            {
                attacking = true;
                targetPosition = player.transform.position;
                returnPosition = transform.position;
            }

            transform.Translate(Vector3.right * xDirection * speed * Time.deltaTime);
            if (xDirection == 1 && transform.position.x > xRange)
            {

                xDirection = -1;

            }
            else if (xDirection == -1 && transform.position.x < -xRange)
            {

                xDirection = 1;

            }
        }
        else
        {
            //Attack Phase
            if (!returning)
            {
                transform.position = Vector3.MoveTowards(transform.position, targetPosition, attackSpeed * Time.deltaTime);
                float distance = Vector3.Distance(transform.position, targetPosition);
                if (Mathf.Approximately(distance, 0f))
                {
                    returning = true;
                }
            }
            else
            {
                //returning to returnPosition
                transform.position = Vector3.MoveTowards(transform.position, returnPosition, speed * Time.deltaTime);
                float distance = Vector3.Distance(transform.position, returnPosition);
                if (Mathf.Approximately(distance, 0f))
                {
                    attacking = false;
                    lastAttackTime = Time.time;
                    returning = false;
                }
            }
        }

     }



    
}

