using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossController : MonoBehaviour
{
    [SerializeField] private int health = 10;
    [SerializeField] private float speed;
    [SerializeField] private float leftEdge;
    [SerializeField] private float rightEdge;
    [SerializeField] private float bottomEdge;
    [SerializeField] private GameObject alienPrefab;
    [SerializeField] private float attackInterval;
    [SerializeField] private GameObject deathFX;

    private float lastAttackTime;
    private float hDirection;
    private bool attacking;
    private bool returning;
    private Vector3 returnPoint;

    // Start is called before the first frame update
    void Start()
    {
        lastAttackTime = Time.time;
        hDirection = 1;
        attacking = false;
        returning = false;  
    }

    // Update is called once per frame
    void Update()
    {
        if  (!attacking && ! returning)
        {
            transform.Translate(Vector3.right * speed * hDirection * Time.deltaTime);
            if (transform.position.x < leftEdge && hDirection == -1)
            {
                hDirection = 1;
            } else if (transform.position.x > rightEdge && hDirection == 1)
            {
                hDirection = -1;
            }
            float attackDelta = Time.time - lastAttackTime;
            if (attackDelta >= attackInterval)
            {
                attacking = true;
                returnPoint = transform.position;
            }
        } else if (attacking)
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
            if (transform.position.z <= bottomEdge && attacking)
            {
                attacking = false;
                returning = true;
                Instantiate(alienPrefab, transform.position, alienPrefab.transform.rotation);
            }
        }else
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
            if (transform.position.z >= returnPoint.z)
            {
                returning = false;
                lastAttackTime = Time.time;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Laser"))
        {
            if(GetComponentsInChildren<LauuncherController>().Length == 0)
            {
                health--;
                if (health == 0)
                {
                    Destroy(gameObject);
                    Instantiate(deathFX, transform.position, Quaternion.identity);
                }
            }
        }
    }



}
