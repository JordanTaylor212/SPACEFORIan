using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [SerializeField] private int health = 3;
    [SerializeField] private GameObject deathFX;
    [SerializeField] private int points;
    

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
     if (other.gameObject.CompareTag("Laser")  || other.gameObject.CompareTag("Player"))
        {
            health--;
            if (health <= 0)
            {
                Destroy(gameObject);
                Instantiate(deathFX, transform.position, Quaternion.identity);
                GameManager.instance.addScore(points);
            }
        }
    
    }
}

