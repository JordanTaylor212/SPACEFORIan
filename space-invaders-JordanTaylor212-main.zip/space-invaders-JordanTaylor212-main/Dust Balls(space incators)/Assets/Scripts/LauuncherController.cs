using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LauuncherController : MonoBehaviour
{
    [SerializeField] private float launchInterval;
    [SerializeField] private GameObject projectilePrefab;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Launch", launchInterval, launchInterval);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void Launch()
    {
        Instantiate(projectilePrefab, transform.position, Quaternion.identity);
    }

}
