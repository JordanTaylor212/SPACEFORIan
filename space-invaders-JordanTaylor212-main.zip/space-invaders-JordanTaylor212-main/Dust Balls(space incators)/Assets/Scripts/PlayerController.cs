using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float xRange;
    [SerializeField] private float zMin;
    [SerializeField] private float zMax;
    [SerializeField] private GameObject laserPrefab;
    [SerializeField] private AudioClip laserSound;
    [SerializeField] private GameObject playerExplosionFX;
    [SerializeField] private Vector3 respawnPoint;
    [SerializeField] private GameObject shield;
    [SerializeField] private AudioClip Ouch;



    private AudioSource audioSource;
    private bool respawn;
    private bool invinsible;



    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        transform.position = respawnPoint;
        respawn = true;
        invinsible = false;
        shield.SetActive(false);
       
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.IsGameOver())
        {
            invinsible = true;
            return;
        }
        if (respawn)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
            if (transform.position.z > zMin)
            {
                respawn = false;
            }
            return;
        }

        float hInput = Input.GetAxis("Horizontal");
        
        float vInput = Input.GetAxis("Vertical");

        Vector3 move = Vector3.right * hInput + Vector3.forward * vInput;
        move = move.normalized * speed;
        transform.Translate(move * Time.deltaTime);
        KeepPlayerOnScreen();

        if (Input.GetButtonDown("Fire1"))
            {
             Instantiate(laserPrefab, transform.position, Quaternion.identity);
            audioSource.PlayOneShot(laserSound);


            }
    }

    void KeepPlayerOnScreen()
    {
        if (transform.position.x < -xRange)
        {
            transform.position = new Vector3(-xRange, transform.position.y, transform.position.z);  
        }

        if(transform.position.x > xRange)
        {
            transform.position = new Vector3(xRange, transform.position.y, transform.position.z);
        }

        if (transform.position.z < zMin)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, zMin);
        }

        if (transform.position.z > zMax)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, zMax);
        }

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy") && !invinsible)
        {
            Instantiate(playerExplosionFX, transform.position, Quaternion.identity);
            GameManager.instance.LoseLife();
            transform.position = respawnPoint;
            respawn = true;
            invinsible = true;
            shield.SetActive(true);
            Invoke("makeVinsible", 3.0f);
            audioSource.PlayOneShot(Ouch);
        }
    }



    private void makeVinsible()
    {
        invinsible = false;
        shield.SetActive(false);
    }

}

